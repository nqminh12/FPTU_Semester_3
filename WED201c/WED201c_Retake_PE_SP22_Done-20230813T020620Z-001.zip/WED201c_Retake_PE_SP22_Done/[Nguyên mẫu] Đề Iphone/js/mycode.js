function CustomerInfo() {
    alert("Thanks you");
}